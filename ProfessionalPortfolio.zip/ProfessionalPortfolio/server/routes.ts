import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // An API endpoint to receive contact form submissions
  app.post('/api/contact', async (req, res) => {
    try {
      const { name, email, subject, message } = req.body;
      
      // Validate form data
      if (!name || !email || !subject || !message) {
        return res.status(400).json({ message: 'All fields are required' });
      }
      
      // Store the contact form data in the database
      await storage.createContact({
        name,
        email,
        subject,
        message
      });
      
      console.log('Contact form submission saved to database:', { name, email, subject });
      
      return res.status(200).json({ 
        success: true,
        message: 'Message received successfully!' 
      });
    } catch (error) {
      console.error('Error processing contact form:', error);
      return res.status(500).json({ 
        success: false,
        message: 'Server error while processing your message' 
      });
    }
  });
  
  // API endpoint to retrieve contact form submissions (admin use only)
  app.get('/api/contacts', async (req, res) => {
    try {
      const contacts = await storage.getContacts();
      return res.status(200).json(contacts);
    } catch (error) {
      console.error('Error retrieving contacts:', error);
      return res.status(500).json({ 
        success: false,
        message: 'Server error while retrieving contacts' 
      });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
