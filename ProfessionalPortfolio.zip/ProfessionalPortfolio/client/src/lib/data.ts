// Skill Data
export const skillsData = [
  {
    title: "Project Management",
    icon: "fas fa-tasks",
    items: [
      "Total site management and coordination",
      "Subcontractor management",
      "Team leadership and delegation",
      "Client communication and reporting",
      "Schedule and milestone tracking"
    ]
  },
  {
    title: "Technical Expertise",
    icon: "fas fa-drafting-compass",
    items: [
      "Detailed estimation and BOQ preparation",
      "Material and labor consumption monitoring",
      "Rate work analysis of materials",
      "Quantity surveying and measurement",
      "Quality control and inspection"
    ]
  },
  {
    title: "Software Proficiency",
    icon: "fas fa-laptop-code",
    items: [
      "AutoCAD for technical drawings",
      "MS Project for scheduling",
      "MS Excel for calculations and analysis",
      "MS Office for documentation",
      "Computer knowledge for project coordination"
    ]
  },
  {
    title: "Financial Management",
    icon: "fas fa-chart-line",
    items: [
      "Budget preparation and control",
      "Cost optimization strategies",
      "Comparison statement preparation",
      "Stage-wise closing of works",
      "Revision costing due to structural changes"
    ]
  },
  {
    title: "Planning & Scheduling",
    icon: "fas fa-clipboard-list",
    items: [
      "Resource allocation",
      "Project timeline management",
      "Risk assessment and mitigation",
      "Workflow optimization",
      "Project sequencing"
    ]
  },
  {
    title: "Communication",
    icon: "fas fa-comments",
    items: [
      "Stakeholder coordination",
      "Client relationship management",
      "Progress reporting and documentation",
      "Technical communication with architects",
      "Team briefing and instruction"
    ]
  }
];

// Experience Data
export const experienceData = [
  {
    period: "Jun 2024 - Mar 2025",
    role: "Project Manager",
    company: "M/s. Rajarathnam Construction Pvt Ltd",
    responsibilities: [
      "Total site management and project coordination",
      "Preparing detailed estimation and BOQ for materials",
      "Monitoring material and labor consumption",
      "Cost control and budget management"
    ]
  },
  {
    period: "Oct 2013 - May 2024",
    role: "Project Manager",
    company: "M/s. SR Foundations",
    responsibilities: [
      "Managed multiple large-scale projects including ID Fresh Food facility and Alpha Group of School",
      "Supervised 250,000 sq.ft KEC International Ltd project in Manali",
      "Led the Ennore SEZ Switchyard Stage 4 project for BHEL"
    ]
  },
  {
    period: "Oct 2011 - Sep 2013",
    role: "Project Manager",
    company: "M/s. AR Foundation",
    responsibilities: [
      "Managed the Amara Samdura project with 6 villas in Palavakkam",
      "Led the Amara Antha project with 25 villas covering 162,500 sq.ft",
      "Coordinated with architects and structural consultants"
    ]
  },
  {
    period: "Sep 2008 - Sep 2011",
    role: "Assistant Project Manager",
    company: "M/s. Sree Builders",
    responsibilities: [
      "Managed the Oswin's project - individual bungalows in Anna Nagar",
      "Oversaw the Kemin Industries project in Gummidipundi",
      "Supervised the Audi Car Showroom project in Anna Salai"
    ]
  },
  {
    period: "May 2006 - Aug 2008",
    role: "Project Engineer",
    company: "M/s. Rajarathnam Construction (P) Ltd",
    responsibilities: [
      "Worked on RC Mehta's Green Park project covering 213,000 sq.ft",
      "Assisted in the RC Rose Wood project in Vilangadupakkam"
    ]
  },
  {
    period: "Jan 2004 - Apr 2006",
    role: "Assistant Project Engineer",
    company: "SAI KRUPA CONSTRUCTIONS",
    responsibilities: [
      "Involved in the SAI VIRUDHA project (G+3) in Mylapore",
      "Worked on Heritage Vijayendra Nagar Phase II with 86 individual bungalows"
    ]
  },
  {
    period: "1993 - 2004",
    role: "Early Career Development",
    company: "Multiple Organizations",
    responsibilities: [
      "Assistant Engineer at SAI KRUPA CONSTRUCTIONS (2001-2003)",
      "Assistant Engineer at SPS CONSTRUCTIONS (1996-2001)",
      "Junior Engineer at SPS CONSTRUCTIONS (1993-1996)"
    ]
  }
];

// Featured Projects
export const featuredProjects = [
  {
    name: "RC Mehta's Green Park",
    area: "213,000 sq.ft",
    description: "Large-scale residential complex at Milk Colony Road, MMC, Chennai.",
    tags: ["Residential", "Project Management", "Rajarathnam Construction"],
    role: "Project Engineer (2006-2008)",
    icon: "fas fa-building"
  },
  {
    name: "KEC International Ltd",
    area: "250,000 sq.ft",
    description: "Large industrial facility in Manali with complex structural requirements.",
    tags: ["Industrial", "Project Management", "SR Foundations"],
    role: "Project Manager (2013-2024)",
    icon: "fas fa-industry"
  },
  {
    name: "Audi Car Showroom",
    area: "20,000 sq.ft",
    description: "Premium automotive showroom at 343, Anna Salai, Chennai with sophisticated design elements.",
    tags: ["Commercial", "High-end Finishes", "Sree Builders"],
    role: "Assistant Project Manager (2008-2011)",
    icon: "fas fa-car"
  }
];

// Additional Projects
export const additionalProjects = [
  {
    name: "Amara Samdura",
    description: "6 Luxury Villas, Palavakkam",
    area: "80,000 sq.ft",
    company: "AR Foundations",
    period: "2011-2013"
  },
  {
    name: "Amara Antha",
    description: "25 Premium Villas, Palavakkam",
    area: "162,500 sq.ft",
    company: "AR Foundations",
    period: "2011-2013"
  },
  {
    name: "Alpha Group of School",
    description: "Educational Complex, T.Nagar",
    area: "200,000 sq.ft",
    company: "SR Foundations",
    period: "2013-2024"
  },
  {
    name: "Ennore SEZ Switchyard",
    description: "Stage 4 - BHEL, Athippattu",
    area: "200,000 sq.ft",
    company: "SR Foundations",
    period: "2013-2024"
  },
  {
    name: "ID Fresh Food Facility",
    description: "Manufacturing Unit, Thirumudivakkam",
    area: "100,000 sq.ft",
    company: "SR Foundations",
    period: "2013-2024"
  },
  {
    name: "RC Rose Wood",
    description: "Residential Complex, Vilangadupakkam",
    area: "53,000 sq.ft",
    company: "Rajarathnam Construction",
    period: "2024-2025"
  },
  {
    name: "Thirupathy Sales Corporation",
    description: "Commercial Building, Parrys",
    area: "75,000 sq.ft",
    company: "SR Foundations",
    period: "2013-2024"
  },
  {
    name: "Heritage Vijayendra Nagar",
    description: "Phase II, 86 Individual Bungalows",
    area: "63,000 sq.ft",
    company: "SAI KRUPA CONSTRUCTIONS",
    period: "2004-2006"
  },
  {
    name: "SAI VIRUDHA",
    description: "G+3 Residential, Mylapore",
    area: "11,200 sq.ft",
    company: "SAI KRUPA CONSTRUCTIONS",
    period: "2004-2006"
  }
];
