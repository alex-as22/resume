import { Card, CardContent } from "@/components/ui/card";

export default function About() {
  return (
    <section id="about" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-start justify-between">
          <div className="md:w-2/5 mb-10 md:mb-0">
            <h2 className="text-3xl font-heading font-bold text-primary-800 mb-6 inline-block pb-2 border-b-4 border-[#f59e0b]">
              About Me
            </h2>
            <p className="text-lg text-gray-700 mb-6">
              I am a dedicated civil engineering professional with over three decades of experience in the construction industry. I've risen through the ranks from Junior Engineer to Project Manager, developing expertise in project planning, estimation, execution, and team management.
            </p>
            <p className="text-lg text-gray-700 mb-6">
              My objective is to explore opportunities where I can apply my skills and abilities to establish a sound career, while being resourceful, innovative and flexible.
            </p>
            <h3 className="text-xl font-heading font-semibold text-primary-800 mb-4">Personal Skills</h3>
            <ul className="list-disc pl-5 text-gray-700 space-y-2 mb-8">
              <li>Comprehensive problem solving ability</li>
              <li>Diplomatic communication skills</li>
              <li>Willingness to learn</li>
              <li>Team facilitation and leadership</li>
            </ul>
          </div>
          
          <div className="md:w-3/5 md:pl-16">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Contact Info Card */}
              <Card className="bg-gray-50 shadow-md">
                <CardContent className="p-6">
                  <h3 className="text-xl font-heading font-semibold text-primary-800 mb-4 flex items-center">
                    <i className="fas fa-address-card text-[#f59e0b] mr-3"></i>
                    Contact Information
                  </h3>
                  <ul className="space-y-3">
                    <li className="flex items-start">
                      <i className="fas fa-map-marker-alt text-gray-500 mt-1 mr-3 w-5 text-center"></i>
                      <span>
                        No.205/1, Poonthottam Street,<br/>
                        Thiruvottriyur, Chennai – 600 019
                      </span>
                    </li>
                    <li className="flex items-center">
                      <i className="fas fa-phone text-gray-500 mr-3 w-5 text-center"></i>
                      <span>9003121430</span>
                    </li>
                    <li className="flex items-center">
                      <i className="fas fa-envelope text-gray-500 mr-3 w-5 text-center"></i>
                      <span>km_ravi@yahoo.co.in</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
              
              {/* Education Card */}
              <Card className="bg-gray-50 shadow-md">
                <CardContent className="p-6">
                  <h3 className="text-xl font-heading font-semibold text-primary-800 mb-4 flex items-center">
                    <i className="fas fa-graduation-cap text-[#f59e0b] mr-3"></i>
                    Education
                  </h3>
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-medium text-gray-800">Diploma in Civil Engineering</h4>
                      <p className="text-gray-600">Pattukottai Polytechnic, Pattukottai</p>
                      <p className="text-sm text-gray-500">1990 – 1993</p>
                    </div>
                    <div>
                      <h4 className="font-medium text-gray-800">Standard X</h4>
                      <p className="text-gray-600">Vellayan Chettiar H.S. School</p>
                      <p className="text-sm text-gray-500">Thiruvottriyur, Chennai</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              {/* Personal Details Card */}
              <Card className="bg-gray-50 shadow-md">
                <CardContent className="p-6">
                  <h3 className="text-xl font-heading font-semibold text-primary-800 mb-4 flex items-center">
                    <i className="fas fa-user text-[#f59e0b] mr-3"></i>
                    Personal Details
                  </h3>
                  <ul className="space-y-2">
                    <li className="flex">
                      <span className="text-gray-600 font-medium w-32">Date of Birth:</span>
                      <span className="text-gray-700">28.05.1973</span>
                    </li>
                    <li className="flex">
                      <span className="text-gray-600 font-medium w-32">Sex:</span>
                      <span className="text-gray-700">Male</span>
                    </li>
                    <li className="flex">
                      <span className="text-gray-600 font-medium w-32">Religion:</span>
                      <span className="text-gray-700">Hindu</span>
                    </li>
                    <li className="flex">
                      <span className="text-gray-600 font-medium w-32">Nationality:</span>
                      <span className="text-gray-700">Indian</span>
                    </li>
                    <li className="flex">
                      <span className="text-gray-600 font-medium w-32">Languages:</span>
                      <span className="text-gray-700">English & Tamil</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
              
              {/* Objective Card */}
              <div className="bg-[#f59e0b] rounded-lg p-6 shadow-md text-white">
                <h3 className="text-xl font-heading font-semibold mb-4 flex items-center">
                  <i className="fas fa-bullseye mr-3"></i>
                  Career Objective
                </h3>
                <p className="leading-relaxed">
                  To explore opportunities where I can apply my skills and abilities to establish a sound career that offers professional growth while being resourceful, innovative and flexible.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
