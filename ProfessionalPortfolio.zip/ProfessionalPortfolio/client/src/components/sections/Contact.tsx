import { useState } from "react";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";

const contactFormSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters long" }),
  email: z.string().email({ message: "Please enter a valid email address" }),
  subject: z.string().min(2, { message: "Subject must be at least 2 characters long" }),
  message: z.string().min(10, { message: "Message must be at least 10 characters long" }),
});

type ContactFormValues = z.infer<typeof contactFormSchema>;

export default function Contact() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const form = useForm<ContactFormValues>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: {
      name: "",
      email: "",
      subject: "",
      message: "",
    },
  });

  async function onSubmit(data: ContactFormValues) {
    setIsSubmitting(true);
    
    try {
      // Send data to our backend API
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });
      
      if (!response.ok) {
        throw new Error('Failed to send message');
      }
      
      console.log("Form data:", data);
      
      toast({
        title: "Message sent successfully!",
        description: "Thank you for your message. I'll get back to you soon.",
      });
      
      form.reset();
    } catch (error) {
      console.error('Contact form error:', error);
      toast({
        title: "Error sending message",
        description: "There was an error sending your message. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <section id="contact" className="py-20 bg-primary-800 text-white">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-heading font-bold mb-12 text-center">Get In Touch</h2>
          
          <div className="flex flex-col md:flex-row gap-8">
            <div className="md:w-1/2">
              <Card className="bg-white text-gray-800 h-full">
                <CardContent className="p-8">
                  <h3 className="text-2xl font-heading font-semibold text-primary-800 mb-6">
                    Contact Information
                  </h3>
                  
                  <div className="space-y-6">
                    <div className="flex items-start">
                      <div className="w-12 h-12 rounded-full bg-primary-100 flex items-center justify-center mr-4 flex-shrink-0">
                        <i className="fas fa-map-marker-alt text-xl text-primary-800"></i>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-800 mb-1">Address</h4>
                        <p className="text-gray-600">
                          No.205/1, Poonthottam Street,<br/>
                          Thiruvottriyur, Chennai – 600 019
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-start">
                      <div className="w-12 h-12 rounded-full bg-primary-100 flex items-center justify-center mr-4 flex-shrink-0">
                        <i className="fas fa-phone text-xl text-primary-800"></i>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-800 mb-1">Phone</h4>
                        <p className="text-gray-600">
                          <a href="tel:+919003121430" className="hover:text-primary-800 transition-colors">
                            +91 9003121430
                          </a>
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-start">
                      <div className="w-12 h-12 rounded-full bg-primary-100 flex items-center justify-center mr-4 flex-shrink-0">
                        <i className="fas fa-envelope text-xl text-primary-800"></i>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-800 mb-1">Email</h4>
                        <p className="text-gray-600">
                          <a href="mailto:km_ravi@yahoo.co.in" className="hover:text-primary-800 transition-colors">
                            km_ravi@yahoo.co.in
                          </a>
                        </p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-8 pt-6 border-t border-gray-200">
                    <h4 className="font-medium text-gray-800 mb-3">Available For:</h4>
                    <div className="flex flex-wrap gap-3">
                      <span className="bg-primary-100 text-primary-800 px-3 py-1 text-sm rounded-full">
                        Full-time Positions
                      </span>
                      <span className="bg-green-100 text-green-800 px-3 py-1 text-sm rounded-full">
                        Consulting
                      </span>
                      <span className="bg-[#fff8e1] text-[#b45309] px-3 py-1 text-sm rounded-full">
                        Project Management
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div className="md:w-1/2">
              <Card className="bg-white text-gray-800">
                <CardContent className="p-8">
                  <h3 className="text-2xl font-heading font-semibold text-primary-800 mb-6">
                    Send a Message
                  </h3>
                  
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                      <FormField
                        control={form.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-gray-700 font-medium">Your Name</FormLabel>
                            <FormControl>
                              <Input 
                                {...field} 
                                className="w-full border-gray-300 rounded-md focus:ring-primary-500"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-gray-700 font-medium">Email Address</FormLabel>
                            <FormControl>
                              <Input 
                                {...field} 
                                type="email" 
                                className="w-full border-gray-300 rounded-md focus:ring-primary-500"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="subject"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-gray-700 font-medium">Subject</FormLabel>
                            <FormControl>
                              <Input 
                                {...field} 
                                className="w-full border-gray-300 rounded-md focus:ring-primary-500"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="message"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-gray-700 font-medium">Message</FormLabel>
                            <FormControl>
                              <Textarea 
                                {...field} 
                                rows={4} 
                                className="w-full border-gray-300 rounded-md focus:ring-primary-500"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <Button 
                        type="submit" 
                        className="w-full bg-[#1d4ed8] hover:bg-[#1e40af] text-white font-medium py-3 rounded-md shadow-md"
                        disabled={isSubmitting}
                      >
                        {isSubmitting ? "Sending..." : "Send Message"}
                      </Button>
                    </form>
                  </Form>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
