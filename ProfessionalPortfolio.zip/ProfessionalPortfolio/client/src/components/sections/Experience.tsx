import { cn } from "@/lib/utils";
import { experienceData } from "@/lib/data";

export default function Experience() {
  return (
    <section id="experience" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-heading font-bold text-primary-800 mb-12 text-center">
          Professional Journey
        </h2>
        
        <div className="relative timeline-container">
          {experienceData.map((exp, index) => (
            <div 
              key={index} 
              className="mb-12 relative pl-10 md:pl-0"
            >
              <div className="timeline-dot"></div>
              <div className={cn(
                "md:w-5/12",
                index % 2 === 0 ? "md:ml-auto md:pl-8 md:pr-0 pr-0" : "md:mr-auto md:pr-8"
              )}>
                <div className={cn(
                  "bg-white rounded-lg p-6 shadow-md hover:shadow-lg transition-shadow border-l-4",
                  index % 2 === 0 ? "border-primary-800" : "border-[#f59e0b]"
                )}>
                  <span className={cn(
                    "inline-block px-3 py-1 rounded-full text-sm font-medium mb-3",
                    index % 2 === 0 ? "bg-primary-100 text-primary-800" : "bg-[#fff8e1] text-[#b45309]"
                  )}>
                    {exp.period}
                  </span>
                  <h3 className="text-xl font-heading font-semibold text-primary-800 mb-2">
                    {exp.role}
                  </h3>
                  <h4 className="text-lg text-gray-700 mb-4">
                    {exp.company}
                  </h4>
                  <ul className="space-y-2 text-gray-600">
                    {exp.responsibilities.map((resp, idx) => (
                      <li key={idx} className="flex items-start">
                        <i className="fas fa-caret-right text-[#f59e0b] mt-1 mr-2"></i>
                        <span>{resp}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <style jsx>{`
        .timeline-container::before {
          content: '';
          position: absolute;
          top: 0;
          left: 17px;
          height: 100%;
          width: 4px;
          background: #e2e8f0;
        }
        @media (min-width: 768px) {
          .timeline-container::before {
            left: 50%;
            margin-left: -2px;
          }
        }
        .timeline-dot {
          position: absolute;
          left: 14px;
          width: 10px;
          height: 10px;
          border-radius: 50%;
          background: #1e3a8a;
          border: 2px solid white;
          top: 20px;
        }
        @media (min-width: 768px) {
          .timeline-dot {
            left: 50%;
            margin-left: -5px;
          }
        }
      `}</style>
    </section>
  );
}
