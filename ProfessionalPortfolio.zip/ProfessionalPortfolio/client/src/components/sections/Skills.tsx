import { Card, CardContent } from "@/components/ui/card";
import { skillsData } from "@/lib/data";

export default function Skills() {
  return (
    <section id="skills" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-heading font-bold text-primary-800 mb-12 text-center">
          Professional Skills
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {skillsData.map((skill, index) => (
            <Card 
              key={index} 
              className="bg-white shadow-md hover:shadow-lg transition-shadow"
            >
              <CardContent className="p-6">
                <div className="flex items-center mb-6">
                  <div className="w-14 h-14 rounded-full bg-primary-100 flex items-center justify-center mr-4">
                    <i className={`${skill.icon} text-2xl text-primary-800`}></i>
                  </div>
                  <h3 className="text-xl font-heading font-semibold text-primary-800">
                    {skill.title}
                  </h3>
                </div>
                <ul className="space-y-3">
                  {skill.items.map((item, idx) => (
                    <li key={idx} className="flex items-start">
                      <i className="fas fa-check text-[#f59e0b] mt-1 mr-3"></i>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
