import { Button } from "@/components/ui/button";
import raviPhoto from "@assets/ravi passportsize photo.jpg";

export default function Hero() {
  return (
    <section className="min-h-screen pt-24 bg-gradient-to-br from-gray-50 to-gray-100 flex items-center">
      <div className="container mx-auto px-4 py-16">
        <div className="flex flex-col md:flex-row items-center justify-between">
          <div className="md:w-1/2 mb-10 md:mb-0">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-heading font-bold text-primary-800 leading-tight">
              KM. Ravi
            </h1>
            <h2 className="text-2xl md:text-3xl font-heading text-[#f59e0b] mt-2 mb-6">
              Project Manager
            </h2>
            <p className="text-lg text-gray-600 mb-8 max-w-xl">
              A seasoned civil engineering professional with 30+ years of experience in construction project management, delivering excellence from concept to completion.
            </p>
            <div className="flex flex-wrap gap-4">
              <Button asChild className="bg-[#1d4ed8] hover:bg-[#1e40af] text-white shadow-md px-6 py-3">
                <a href="#contact">Contact Me</a>
              </Button>
              <Button asChild variant="outline" className="bg-white text-primary-800 border-primary-800 hover:bg-gray-50 shadow-sm px-6 py-3">
                <a href="#projects">View Projects</a>
              </Button>
            </div>
          </div>
          <div className="md:w-2/5">
            <div className="relative">
              <img 
                src={raviPhoto} 
                alt="KM Ravi" 
                className="rounded-full w-64 h-64 md:w-80 md:h-80 mx-auto object-cover border-8 border-white shadow-xl"
              />
              <div className="absolute inset-0 rounded-full border-4 border-primary-100 animate-pulse"></div>
            </div>
          </div>
        </div>

        <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 hidden md:block animate-bounce">
          <a href="#about" className="text-gray-400 hover:text-primary-800 transition-colors">
            <i className="fas fa-chevron-down text-2xl"></i>
          </a>
        </div>
      </div>
    </section>
  );
}
