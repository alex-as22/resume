import { Card, CardContent } from "@/components/ui/card";
import { featuredProjects, additionalProjects } from "@/lib/data";

export default function Projects() {
  return (
    <section id="projects" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-heading font-bold text-primary-800 mb-12 text-center">
          Notable Projects
        </h2>
        
        {/* Featured Projects */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {featuredProjects.map((project, index) => (
            <div key={index} className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-shadow">
              <div 
                className="w-full h-56 bg-gradient-to-br from-primary-100 to-primary-300 flex items-center justify-center"
              >
                <i className={`${project.icon} text-5xl text-primary-800`}></i>
              </div>
              <div className="p-6">
                <div className="flex justify-between items-start mb-3">
                  <h3 className="text-xl font-heading font-semibold text-primary-800">
                    {project.name}
                  </h3>
                  <span className="text-sm bg-[#fff8e1] text-[#b45309] px-2 py-1 rounded">
                    {project.area}
                  </span>
                </div>
                <p className="text-gray-600 mb-4">{project.description}</p>
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.tags.map((tag, idx) => (
                    <span key={idx} className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded">
                      {tag}
                    </span>
                  ))}
                </div>
                <div className="flex items-center text-sm text-gray-500">
                  <i className="fas fa-user-hard-hat mr-2"></i>
                  <span>{project.role}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        {/* Project List */}
        <Card className="bg-white shadow-lg">
          <CardContent className="p-6 md:p-8">
            <h3 className="text-2xl font-heading font-semibold text-primary-800 mb-6">
              Additional Project Experience
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-8">
              {additionalProjects.map((project, index) => (
                <div 
                  key={index} 
                  className={`border-l-4 ${index % 2 === 0 ? 'border-primary-800' : 'border-[#f59e0b]'} pl-4`}
                >
                  <h4 className="font-medium text-lg text-primary-800">{project.name}</h4>
                  <p className="text-gray-600 text-sm mb-1">{project.description}</p>
                  <p className="text-gray-500 text-sm mb-2">{project.area} | {project.company}</p>
                  <div className="flex items-center text-sm text-gray-500">
                    <i className="fas fa-calendar-alt mr-2"></i>
                    <span>{project.period}</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
