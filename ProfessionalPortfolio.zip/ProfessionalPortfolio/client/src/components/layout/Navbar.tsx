import { useState, useEffect } from "react";
import { Link } from "wouter";
import { cn } from "@/lib/utils";
import { useScrollProgress } from "@/hooks/useScrollProgress";

const navLinks = [
  { name: "About", href: "#about" },
  { name: "Skills", href: "#skills" },
  { name: "Experience", href: "#experience" },
  { name: "Projects", href: "#projects" },
  { name: "Contact", href: "#contact" },
];

export default function Navbar() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const scrollProgress = useScrollProgress();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  const handleMobileNavClick = () => {
    setMobileMenuOpen(false);
  };

  return (
    <header className="fixed w-full bg-white shadow-md z-50 transition-all duration-300">
      {/* Scroll Progress Indicator */}
      <div 
        className="h-[3px] bg-[#f59e0b] fixed top-0 left-0 z-[999]" 
        style={{ width: `${scrollProgress}%` }}
      />

      <div className={cn(
        "container mx-auto px-4 py-3 flex justify-between items-center transition-all duration-300",
        isScrolled && "py-2"
      )}>
        <div>
          <h1 className="text-2xl font-heading font-bold text-primary-800">
            KM. <span className="text-[#f59e0b]">Ravi</span>
          </h1>
          <p className="text-sm text-gray-500 hidden md:block">Civil Engineering Professional</p>
        </div>
        
        <nav className="hidden md:block">
          <ul className="flex space-x-6">
            {navLinks.map((link) => (
              <li key={link.name}>
                <a 
                  href={link.href}
                  className="font-medium text-gray-600 hover:text-primary-800 transition-colors"
                >
                  {link.name}
                </a>
              </li>
            ))}
          </ul>
        </nav>
        
        <button 
          onClick={toggleMobileMenu}
          className="md:hidden text-gray-600 focus:outline-none"
          aria-label="Toggle mobile menu"
        >
          {mobileMenuOpen ? (
            <i className="fas fa-times text-xl"></i>
          ) : (
            <i className="fas fa-bars text-xl"></i>
          )}
        </button>
      </div>
      
      {/* Mobile Menu */}
      <div className={cn(
        "md:hidden bg-white px-4 py-3 shadow-inner",
        mobileMenuOpen ? "block" : "hidden"
      )}>
        <ul className="space-y-3">
          {navLinks.map((link) => (
            <li key={link.name}>
              <a
                href={link.href}
                className="block font-medium text-gray-600 hover:text-primary-800 transition-colors py-2"
                onClick={handleMobileNavClick}
              >
                {link.name}
              </a>
            </li>
          ))}
        </ul>
      </div>
    </header>
  );
}
