export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-10">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-6 md:mb-0">
            <h2 className="text-2xl font-heading font-bold">
              KM. <span className="text-[#f59e0b]">Ravi</span>
            </h2>
            <p className="text-gray-400">Civil Engineering Professional</p>
          </div>
          
          <div className="flex flex-wrap justify-center gap-4 mb-6 md:mb-0">
            <a href="#about" className="text-gray-400 hover:text-white transition-colors">About</a>
            <a href="#skills" className="text-gray-400 hover:text-white transition-colors">Skills</a>
            <a href="#experience" className="text-gray-400 hover:text-white transition-colors">Experience</a>
            <a href="#projects" className="text-gray-400 hover:text-white transition-colors">Projects</a>
            <a href="#contact" className="text-gray-400 hover:text-white transition-colors">Contact</a>
          </div>
          
          <div>
            <div className="flex gap-4">
              <a 
                href="mailto:km_ravi@yahoo.co.in" 
                className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-primary-800 transition-colors"
                aria-label="Email"
              >
                <i className="fas fa-envelope"></i>
              </a>
              <a 
                href="tel:+919003121430" 
                className="w-10 h-10 rounded-full bg-gray-800 flex items-center justify-center hover:bg-primary-800 transition-colors"
                aria-label="Phone"
              >
                <i className="fas fa-phone"></i>
              </a>
            </div>
          </div>
        </div>
        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-500 text-sm">
          <p>&copy; {new Date().getFullYear()} KM Ravi. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
