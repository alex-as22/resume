import { useState, useEffect } from 'react';

export function useScrollProgress() {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const updateScroll = () => {
      // Calculate scroll progress as percentage
      const scrollTop = window.scrollY;
      const scrollHeight = document.documentElement.scrollHeight - window.innerHeight;
      const scrollPercentage = scrollTop / scrollHeight * 100;
      
      setProgress(scrollPercentage);
    };

    // Add event listener for scroll
    window.addEventListener('scroll', updateScroll);
    
    // Initial calculation
    updateScroll();
    
    // Clean up
    return () => window.removeEventListener('scroll', updateScroll);
  }, []);

  return progress;
}
